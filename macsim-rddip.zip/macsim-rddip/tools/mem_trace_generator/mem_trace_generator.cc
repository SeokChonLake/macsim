#include "trace_generator.h" 
namespace std; 


int main(int argc, char *argv[]) 
{
  printf("generating traces \n"); 
  // write_inst_to_file(ofstream *file, Inst_info *t_info); 

} 

