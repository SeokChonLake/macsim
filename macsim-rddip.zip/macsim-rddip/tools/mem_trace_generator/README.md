memory trace generator from multiple different input types. 
type 0: default stream generator (by modifying define, can generate traces that are dependent or independent)
type 1:  convert ramulator trace output file format to macsim trace 

to convert hmc_sim's output files to the macsim traces, 
   first we use hmcsim_trace_conv.py to covert the trace format to ramulator's trace format and then execute mem_trace 

====== 
 how to execute 
=======  



