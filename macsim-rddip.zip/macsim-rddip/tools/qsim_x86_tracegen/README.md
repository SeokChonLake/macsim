q2m-sim
=======

A tool that uses QSim to generate x86 instruction traces that can be fed to MacSim
