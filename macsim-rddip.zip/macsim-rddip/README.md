#yongwoo modifeid
use re-use distance dynamic insertion policy

this version is not merge calculate re-use distance and give rrpv

Use the re-use distance information with another file and give rrpv ordering with re-use distance that we already known