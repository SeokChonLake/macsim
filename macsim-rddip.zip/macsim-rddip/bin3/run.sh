mkdir W3
./macsim --l3_repl==TRUD | tee -i ./W3/W3.stdout
