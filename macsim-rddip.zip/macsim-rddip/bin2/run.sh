mkdir W1
./macsim --l3_repl==TRUD | tee -i ./W1/W1.stdout
