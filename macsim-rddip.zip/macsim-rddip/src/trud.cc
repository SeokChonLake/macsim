#include "assert_macros.h"
#include "trud.h"
#include "utils.h"

#include "debug_macros.h"

#include "all_knobs.h"

#include <algorithm>
#include <cstdlib>
#include <ctime>

#define DEBUG(args...) _DEBUG(*m_simBase->m_knobs->KNOB_DEBUG_CACHE_LIB, ## args)
#define DEBUG_MEM(args...) _DEBUG(*m_simBase->m_knobs->KNOB_DEBUG_MEM_TRACE, ## args)

#define LONG_RRPV       ((1 << m_rrpv_len) - 2)
#define DISTANT_RRPV    ((1 << m_rrpv_len) - 1)

#define GET_PROB (static_cast <double> (rand()) / static_cast <float> (RAND_MAX))

trud_cache_c::trud_cache_c(string name, int num_set, int assoc, int line_size, int data_size, int bank_num,
		bool cache_by_pass, int core_id, Cache_Type cache_type_info, bool enable_partition,
		int num_tiles, int interleave_factor, macsim_c* simBase)
: cache_c(name, num_set, assoc, line_size, data_size, bank_num,
		cache_by_pass, core_id, cache_type_info, enable_partition,
		num_tiles, interleave_factor, simBase)
{
	int appl_num=*KNOB(KNOB_NUM_SIM_CORES);

	//m_num_sets = num_set;
	m_num_cores=*KNOB(KNOB_NUM_SIM_CORES);
	m_shadow_set = new cache_set_c**[appl_num];
	reuse_dist= new uns32[appl_num];
	reuse_dist_access_cnt = new uns32[appl_num];
	
	appl_hit_cnt =new uns32[appl_num];
	appl_access_cnt=new uns32[appl_num];
	rrpv_of_appl_1 =5;
	for(int kk=0;kk<appl_num;kk++){
		//yongwoo
		reuse_dist[kk]=0;
		reuse_dist_access_cnt[kk]=0;
		appl_hit_cnt[kk]=0;
		appl_access_cnt[kk]=0;
		m_shadow_set[kk]=new cache_set_c*[num_set];

		//shadow cache for each application
		for (int ii = 0; ii < num_set; ++ii) {
			m_shadow_set[kk][ii] = new cache_set_c(m_assoc); 
	
   	 // Allocating memory for all of the data elements in each line
    		for (int jj = 0; jj < assoc; ++jj) {
				m_shadow_set[kk][ii]->m_entry[jj].m_valid          = false;
				m_shadow_set[kk][ii]->m_entry[jj].m_access_counter = false;
				if (data_size > 0) {
   	    		 	m_shadow_set[kk][ii]->m_entry[jj].m_data = (void *)malloc(data_size);
   	    		 	memset(m_shadow_set[kk][ii]->m_entry[jj].m_data, 0, data_size);
				}	  
				else {
					m_shadow_set[kk][ii]->m_entry[jj].m_data = INIT_CACHE_DATA_VALUE;
				}
			}
		}
	}
	m_rrpv_len=5;  //dont erase
}

trud_cache_c::~trud_cache_c()// : ~cache_c()
{
//	delete[] m_pstate;
}

void* trud_cache_c::access_cache(Addr addr, Addr *line_addr, bool update_repl, int appl_id) 
{
  // Check if cache by pass is set. If so return NULL.
  if (m_cache_by_pass)
    return NULL;

  Addr tag;
  int set;

  //YW
//  cout << __FUNCTION__ << endl;
  // Get Tag and set to check if the addr exists in cache
  find_tag_and_set(addr, &tag, &set);
  *line_addr = base_cache_line (addr);
  

  if (update_repl){
    update_cache_on_access(*line_addr, set, appl_id);
	appl_access_cnt[appl_id]++;
	}
  // Walk through the set
  for (int ii = 0; ii < m_assoc; ++ii) {
    // For each line in based on associativity
    cache_entry_c * line = &(m_set[set]->m_entry[ii]);

    // Check for matching tag and validity
    if (line->m_valid && line->m_tag == tag) {
      appl_hit_cnt[appl_id]++;
	//  uns32 m_reuse_dist;
	  // If hit, then return  
      assert(line->m_data);
	//  m_reuse_dist =  CYCLE-m_shadow_set[appl_id][set]->m_entry[ii].m_last_access_time;
	//  cout<<"appl_id" << appl_id<<":cycle:" <<CYCLE<<":reuse distance:"
	//  << m_reuse_dist<<endl;
	//  reuse_dist[appl_id]+=(uns32)(m_reuse_dist/100000);
	 // reuse_dist_access_cnt[appl_id]++;
	   
	 // m_shadow_set[appl_id][set]->m_entry[ii].m_last_access_time=CYCLE;

      if (update_repl) {
        // If prefetch is set mark it as used  
        if (line->m_pref) {
          line->m_pref = false;
        }
        update_line_on_hit(line, set, appl_id);
      }   

      return line->m_data;
    }
  }

  if (update_repl)
    update_cache_on_miss(set, appl_id);

  return NULL;
}

void trud_cache_c::update_cache_on_miss(int set, int appl_id)
{
/*	switch(m_pstate[set]) {
		case NONE:
			break;
		case FOLLOWER:
			break;
		case SRRIP:
			m_psel[SRRIP]++;
			break;
		case BRRIP:
			m_psel[BRRIP]++;
			break;
		default:
			exit(-1);
	}*/
}

void trud_cache_c::initialize_cache_line(cache_entry_c *ins_line, Addr tag, Addr addr, int appl_id, bool gpuline, int set_id, bool skip)
{
	ins_line->m_valid           = true;
	ins_line->m_tag             = tag;
	ins_line->m_base            = (addr & ~m_offset_mask);
	ins_line->m_access_counter  = 0;
	ins_line->m_pref            = false;
	ins_line->m_skip            = skip;

	ins_line->m_appl_id         = appl_id;
	ins_line->m_gpuline         = gpuline;

	if (ins_line->m_gpuline) {
		++m_num_gpu_line;
		++m_set[set_id]->m_num_gpu_line;
	}
	else {
		++m_num_cpu_line;
		++m_set[set_id]->m_num_cpu_line;
	}

	int tmp=DISTANT_RRPV/(m_num_cores-1);
	for(int ii=0;ii<m_num_cores;ii++){
		if(appl_id==ii){
			if(appl_id==m_num_cores-1)
				ins_line->m_last_access_time=DISTANT_RRPV;
			else ins_line->m_last_access_time=tmp*ii;
			//cout << ins_line->m_last_access_time <<endl;
		}
	}

	
	// temporally setting  - modified after
/*	if(appl_id==0)
		ins_line->m_last_access_time=0;
	else if(appl_id==1)
		ins_line->m_last_access_time=rrpv_of_appl_1;
	else if(appl_id==2)
		ins_line->m_last_access_time=rrpv_of_appl_1+10;
	else
		ins_line->m_last_access_time = DISTANT_RRPV;
		*/
	// Select insertion policy
/*
	switch(m_pstate[set_id])
	{
		case NONE:
		case FOLLOWER:
			if (m_psel[SRRIP] > m_psel[BRRIP])
				goto LABEL_BRRIP;
		case SRRIP:
			ins_line->m_last_access_time = LONG_RRPV;
			break;
		case BRRIP:
LABEL_BRRIP:
			if (GET_PROB <= m_epsilon)
				ins_line->m_last_access_time = LONG_RRPV;
			else
				ins_line->m_last_access_time = DISTANT_RRPV;
			break;
	}
*/
}

// Extract victim cache line from Long RRPV position
cache_entry_c* trud_cache_c::find_replacement_line(int set, int appl_id)
{
	int RRIP_tail_ind = 0;

	// If free entry found, return it
	for (int ii = 0; ii < m_assoc; ii++)
	{
		cache_entry_c* line = &(m_set[set]->m_entry[ii]);
	//	cache_entry_c* line_shadow =&(m_shadow_set[appl_id][set]->m_entry[ii]);
		if (!line->m_valid) {

//			m_shadow_set[appl_id][set]->m_entry[ii].m_last_access_time=CYCLE;
			return line;
		}
	}

	while(1) {
		RRIP_tail_ind = -1;
		// if the distant re-reference interval prediction value entry found, return it
		for(int ii = 0; ii < m_assoc; ii++)
		{
			cache_entry_c* line = &(m_set[set]->m_entry[ii]);
			// use m_last_access_time as a rrpv
			if(line->m_last_access_time >= DISTANT_RRPV)
			{
				// TODO: Need to break a tie 
				RRIP_tail_ind = ii;
				return &(m_set[set]->m_entry[ii]);
			}
		}
		if (RRIP_tail_ind == -1) // Can't find distant RRPV, do aging for all entry
		{
			for (int ii = 0; ii < m_assoc; ii++)
			{
				cache_entry_c* line = &(m_set[set]->m_entry[ii]);
				line->m_last_access_time++;
			}
		}
		else{
		    	// long RRPV entry found, return it
			return &(m_set[set]->m_entry[RRIP_tail_ind]);
		}
	}
}

void trud_cache_c::update_line_on_hit(cache_entry_c* line, int set, int appl_id)
{
	if (line->m_last_access_time >= 1)
		line->m_last_access_time--;
	else
		line->m_last_access_time = 0;
}

void trud_cache_c::update_cache_policy(Counter m_cycle)
{
	static uns32 check = 10; 
	uns32 check_point = m_cycle / 1000000;
//	cout<<check_point<< " / " <<m_cycle<<"/";
	if (check_point > check)
	{
		cout<< "<rrpv of application 1 : "<< rrpv_of_appl_1<<">"<<endl; 
		for(int ii=0;ii<m_num_cores;ii++){
			int appl_id=ii;
			cout<<"appl_id"<<appl_id<<"hit :"<< appl_hit_cnt[ii] <<" /access " << appl_access_cnt[ii];
			if(appl_access_cnt!=0)
				cout << "ratio:" << (double)(appl_hit_cnt[ii])/(double)appl_access_cnt[ii]<<endl;
			else
				cout << "ratio:0"<<endl;
			appl_hit_cnt[ii]=0;
			appl_access_cnt[ii]=0;
		}
		
		if(rrpv_of_appl_1!=31)
			rrpv_of_appl_1++;
		/*for(int i=0;i<m_num_cores;i++){
			if(reuse_dist_access_cnt[i]!=0)
				cout << i<<":"<<reuse_dist[i]/reuse_dist_access_cnt[i] <<endl;
			else
				cout << i<<" no access yet " <<endl;

		}*/
		check++;
	}

}
